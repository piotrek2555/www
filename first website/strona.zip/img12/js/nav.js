//nav

function openNav() {

// rozsuniecie tresci 
var nav = document.getElementById("tresc");
 nav.classList.toggle("menu-canvas");

//zmiana klasy- pojawienie sie menu 

var m = document.getElementById("menu");


	 m.classList.toggle("mobile-active")
	 
	
	 
	 
}




//zamykanie menu 

function closeNav() {
	var nav = document.getElementById("tresc");
	nav.style.marginLeft = "0px"
	
	
	
	
	
}



